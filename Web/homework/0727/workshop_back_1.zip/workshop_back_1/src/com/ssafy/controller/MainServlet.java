package com.ssafy.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/main")
public class MainServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private List<Book> list = new ArrayList<Book>();
    
    public void init() {
        list.add(new Book("a1111", "java 해부하기", "SSAFY출판", 25000, "자바를 위한 입문서."));
        list.add(new Book("a2222", "BackEnd란", "JAEN출판사", 25000, "백엔드를 마스터하고 싶나?"));
        list.add(new Book("a3333", "Spring Framework", "삼성출판", 25000, "스프링 넘나 어려워."));
        list.add(new Book("a4444", "공부잘하는방법", "SSAFY출판", 25000, "싸피로 와라~!"));
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        execute(request, response);
    }
    
    private void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        String targetJsp = "";
        
        if("main".equals(action)) {
          
            targetJsp = "WEB-INF/regist.html";
        }else if("regist".equals(action)) {
            String isbn = request.getParameter("isbn");
            String title = request.getParameter("title");
            String author = request.getParameter("author");
            int price = Integer.parseInt(request.getParameter("price"));
            String desc = request.getParameter("desc");
            
            Book book = new Book(isbn, title, author, price, desc);
            request.setAttribute("Book", book);
            targetJsp = "regist_result.jsp";
        }
        
        RequestDispatcher dispatcher = request.getRequestDispatcher(targetJsp);
        dispatcher.forward(request, response);
    }
    
    private Book getBookByIsbn(String isbn) {
        Book bookDto = null;
        for(Book book : list) {
            if(book.getIsbn().equals(isbn)) {
                bookDto = book;
                break;
            }
        }
        return bookDto;
    }
}
